Survey Technical Office - RV42 base + V33 CAD output integration

الأساس: SurveyQuantAndroid_v1.0.42_ENGINEERING_UI_LEVELS_FIX
الإصدار: 1.0.43
Target SDK: 33
Compile SDK: 35

تم دمج:
- كود إخراج DXF الهندسي الأقوى من V33.
- إخراج المناسيب وإعادة بناء لوحة CAD.
- توجيه اللوحات وإخراج DXF R12.
- مقارنة Job مع NGL وحساب Cut/Fill وإخراج لوحة المقارنة.
- الحفاظ على مشاريع RV42: الطرق، المواسير، مساحات الأراضي، PDF إلى DXF، الدفع.

GitHub Actions: .github/workflows/build-apk.yml
