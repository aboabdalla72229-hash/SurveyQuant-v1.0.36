package com.surveyquant.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p != null && p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(i, FILE_PICKER); }
                catch(Exception e){ if(uploadCallback!=null) uploadCallback.onReceiveValue(null); uploadCallback=null; return false; }
                return true;
            }
        });
        setContentView(web);
        if (android.os.Build.VERSION.SDK_INT >= 23 && android.os.Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 2001);
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r!=FILE_PICKER || uploadCallback==null) return;
        if(c!=RESULT_OK || d==null){ uploadCallback.onReceiveValue(null); uploadCallback=null; return; }
        try {
            if(d.getClipData()!=null){
                int n=d.getClipData().getItemCount();
                Uri[] uris=new Uri[n];
                for(int i=0;i<n;i++){ uris[i]=d.getClipData().getItemAt(i).getUri(); persistReadPermission(uris[i]); }
                uploadCallback.onReceiveValue(uris);
            } else {
                Uri u=d.getData();
                if(u!=null) persistReadPermission(u);
                uploadCallback.onReceiveValue(u!=null?new Uri[]{u}:null);
            }
        } catch(Exception e){ uploadCallback.onReceiveValue(null); }
        uploadCallback=null;
    }

    private void persistReadPermission(Uri u){
        if(u==null) return;
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
    }

    public static class AndroidBridge {
        private static final String CHANNEL_ID = "surveyquant_downloads";
        private final Context context;
        AndroidBridge(Context c){ context=c.getApplicationContext(); }

        @JavascriptInterface
        public String saveFile(String filename, String mime, String base64) {
            try {
                String safeName = filename == null ? "SurveyQuant_Output.bin" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                String safeMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SurveyQuant");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if(uri == null) return "ERROR: cannot create Downloads entry";
                    try(OutputStream out=context.getContentResolver().openOutputStream(uri)){
                        if(out == null) throw new Exception("cannot open output stream");
                        out.write(bytes);
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    context.getContentResolver().update(uri, done, null, null);
                    return uri.toString();
                }

                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                        context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    return "ERROR: storage permission not granted";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SurveyQuant");
                if (!dir.exists() && !dir.mkdirs()) return "ERROR: cannot create Downloads/SurveyQuant";
                File outFile = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(outFile)) {
                    out.write(bytes);
                    out.flush();
                }
                return FileProvider.getUriForFile(context, "com.surveyquant.app.fileprovider", outFile).toString();
            } catch(Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public boolean notifyDownload(String filename, String uriString, String mime) {
            try {
                String name = (filename == null || filename.trim().isEmpty()) ? "SurveyQuant_Output" : filename;
                String type = (mime == null || mime.isEmpty()) ? "*/*" : mime;
                Intent open = new Intent(Intent.ACTION_VIEW);
                open.setDataAndType(Uri.parse(uriString), type);
                open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                int flags = android.os.Build.VERSION.SDK_INT >= 23 ?
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE :
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                android.app.PendingIntent pending = android.app.PendingIntent.getActivity(context, Math.abs(name.hashCode()), open, flags);

                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm == null) return false;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تنزيلات SurveyQuant", NotificationManager.IMPORTANCE_DEFAULT);
                    ch.setDescription("إشعارات الملفات التي تم استخراجها من SurveyQuant");
                    nm.createNotificationChannel(ch);
                }
                NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(com.surveyquant.app.R.drawable.ic_surveyquant)
                        .setContentTitle("تم التنزيل")
                        .setContentText(name)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("تم تنزيل الملف: " + name + "\nاضغط لفتحه."))
                        .setContentIntent(pending)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setCategory(NotificationCompat.CATEGORY_PROGRESS);
                nm.notify(Math.abs((name + System.currentTimeMillis()).hashCode()), builder.build());
                return true;
            } catch(Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean openFile(String uriString, String mime) {
            try {
                if(uriString==null || uriString.isEmpty()) return false;
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.parse(uriString), mime==null||mime.isEmpty()?"*/*":mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return true;
            } catch(Exception e){ return false; }
        }
    }

    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
